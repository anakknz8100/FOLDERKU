=== Simple Website Logo ===
Contributors: lpkapil
Tags: website logo, logo, simple website logo
Requires at least: 6.0
Tested up to: 6.7.1
Stable tag: 1.1
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A plugin to manage wordpress website logo, shortcode [WEBSITE_LOGO]

== Description ==
A plugin to manage wordpress website logo, shortcode [WEBSITE_LOGO]

== Installation ==
1. Upload plugin zip file \'website-logo.zip\' and activate plugin
2. From Appearance > Logo, configure logo from url or file Upload
3. Shortcode [WEBSITE_LOGO] to display logo in default image size
4. For custom logo size use shortcode [WEBSITE_LOGO height="100" width="200"]

== Frequently Asked Questions ==
Question: How can i use this in page templates or php files ?

Answer: just simply add this code:

$height,$width = height and width of logo image numeric, eg: getWebsiteLogo(10,10);

== Screenshots ==
1. https://i.postimg.cc/dtpGkMvw/Capture.png

== Changelog ==
released starting version 1.0
released version 1.1, bug fixes improvements
