(function($) {

    // Handle the keyup event (e.g., when the user types in the logo input)
    $('.choose_logo').on('keyup', function() {
        var logoUrl = $('img', this).attr('src'); // Get the image src from the clicked element
        var ext = logoUrl.split("."); // Split URL by the dot to get file extension
        var extLast = ext[ext.length - 1].toLowerCase(); // Get the last element (file extension), convert to lowercase for comparison

        console.log(extLast); // Check if the extension is valid

        // Check if the file extension is one of the allowed types
        if (extLast !== 'jpg' && extLast !== 'jpeg' && extLast !== 'png' && extLast !== 'gif') {
            $('#website_logo').val(''); // Clear the input if it's not a valid image type
            $('.hide_settings').empty().html('Please Upload Image File Only').delay(1000).fadeIn('slow');
        } else {
            $('#website_logo').val(logoUrl); // Set the URL in the input field
        }
    });

    // When the "Choose Logo" button is clicked
    $(document).ready(function() {
        $('.choose_logo').click(function() {
            // Open WordPress media uploader
            var field = $('#wpss_upload_image').attr('name');
            tb_show('', 'media-upload.php?type=image&TB_iframe=true'); // Open the uploader
            return false;
        });

        // This is the callback function after selecting the image
        window.send_to_editor = function(html) {
			console.log('kapil here..');
			console.log(html); // Inspect the full HTML string being passed
		
			// Create a temporary jQuery object from the HTML string
			var tempDiv = $('<div>').html(html); // Wrap the HTML in a temporary container
		
			// Now find the 'img' tag within the temporary div
			var logoUrl = tempDiv.find('img').attr('src'); // Extract the 'src' attribute
		
			console.log(logoUrl); // Should print the correct image URL
			$('#website_logo').val(logoUrl); // Set the image URL in the input field
			tb_remove(); // Close the thickbox
		};
		
		// Hide the settings after a delay
        $('.hide_settings').delay(1000).fadeOut('slow');
    });

})(jQuery);
