<?php
/**
 * Plugin Name: Simple Website Logo
 * Plugin URI: http://infogiants.com/
 * Description: A plugin to manage wordpress website logo, shortcode [WEBSITE_LOGO] or [WEBSITE_LOGO height="100" width="200"]
 * Version: 1.1
 * Author: InfoGiants
 * Author URI: http://infogiants.com/
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Stable tag: 1.1
 */

if(! function_exists('websiteLogoPage')){

	function websiteLogoPage(){

		add_theme_page('Logo', 'Logo', 'edit_theme_options', 'website_logo', 'rednerWebsiteLogo');
	}
}

if(! function_exists('rednerWebsiteLogo')){


	function rednerWebsiteLogo(){

		wp_enqueue_style('thickbox');
		wp_enqueue_script('thickbox');
		wp_enqueue_script( 'media-upload'); 

		$logo_url	=	get_option('website_logo_unique');

		// Form
		$renderLogo	=	"<div class='wrap'><h2>Website Logo</h2>";

		if(array_key_exists('is_web_logo', $_POST) && $_POST['is_web_logo'] == 'is_web_logo'){

			$renderLogo	.=	"<div id='setting-error-settings_updated' class='updated settings-error hide_settings'>
							<p><strong>Settings saved.</strong></p></div>";
		}
		
		$renderLogo .= "<form method='post'>
                    <table class='form-table'>
                        <tbody>
                            <tr>
                                <th scope='row'><label for='blogname'>Upload Logo</label></th>
                                <td>
                                    <input name='website_logo' id='website_logo' value='" . esc_attr($logo_url) . "' class='regular-text' type='text'>
                                    <a href='media-upload.php?type=image&TB_iframe=true' title='Choose Image' class='thickbox button'>Upload</a>
                                </td>
                            </tr>";

		if (!empty($logo_url)) {
			$renderLogo .= "<tr>
								<th scope='row'><label for='preview'>Logo Preview</label></th>
								<td><img src='" . esc_url($logo_url) . "' width='100' height='100'></td>
							</tr>";
		} else {
			$renderLogo .= "<tr>
								<th scope='row'><label for='preview'>Logo Preview</label></th>
								<td>No logo uploaded</td>
							</tr>";
		}

		$renderLogo .= "</tbody>
							</table>
							<input type='hidden' name='is_web_logo' value='is_web_logo'>
							<p class='submit'>
								<input name='submit' id='submit' class='button button-primary' value='Save Changes' type='submit'>
							</p>
						</form>
						<hr>
						<h3>Documentation</h3>
						<p><b>Use shortcode for default image size:</b> [WEBSITE_LOGO]</p>
						<p><b>Use shortcode for custom image size:</b> [WEBSITE_LOGO height='100' width='200']</p>
						<p><b>For using inside php templates, original size:</b> eg: getWebsiteLogo();</p>
						<p><b>For using inside php templates, custom height & width parameters:</b> eg: getWebsiteLogo(10,10);</p>
						<p><b>For any other help or queries visit: </b><a href='https://www.infogiants.com/' target='_blank'>https://www.infogiants.com/</a></p>
					</div>";


		echo 	$renderLogo;
		
		//JS
		wp_enqueue_script('web',plugins_url( '/js/web.js' , __FILE__ ));				
	}
}

if(! function_exists('saveWebsiteLogo')){

	function saveWebsiteLogo(){

		if(array_key_exists('is_web_logo', $_POST) && $_POST['is_web_logo']){
			$logo_url	=	sanitize_text_field($_POST['website_logo']);
			update_option('website_logo_unique', $logo_url);
		}
	}
}


if (!function_exists('getWebsiteLogo')) {

    // Define the function
    function getWebsiteLogo($atts) {
        // Set default values for height and width (fallback to 'auto')
        $atts = shortcode_atts(
            array(
                'height' => 'auto',
                'width'  => 'auto',
            ),
            $atts,
            'WEBSITE_LOGO'
        );

        // Get the logo URL from the WordPress options
        $logo = get_option('website_logo_unique');
        
        // If logo URL exists, output the image tag
        if ($logo) {
            return '<img src="' . esc_url($logo) . '" width="' . esc_attr($atts['width']) . '" height="' . esc_attr($atts['height']) . '">';
        } else {
            return 'Logo not available.';
        }
    }

    // Add the shortcode
    add_shortcode('WEBSITE_LOGO', 'getWebsiteLogo');
}




// Hooks
add_action('admin_menu', 'websiteLogoPage');
add_action('admin_init', 'saveWebsiteLogo');
?>